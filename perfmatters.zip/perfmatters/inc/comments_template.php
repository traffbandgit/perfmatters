<?php
/* Blank Comments Template */